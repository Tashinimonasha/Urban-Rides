﻿namespace Urban_Rides
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bill));
            this.txtbillcusid = new System.Windows.Forms.TextBox();
            this.lblcusID = new System.Windows.Forms.Label();
            this.lblvehiclenumber = new System.Windows.Forms.Label();
            this.lblindate = new System.Windows.Forms.Label();
            this.rentoutdate = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblrenteddate = new System.Windows.Forms.Label();
            this.txtrec = new System.Windows.Forms.TextBox();
            this.lblrecieptnum = new System.Windows.Forms.Label();
            this.lbltotalamount = new System.Windows.Forms.Label();
            this.lbltotalamountdisplay = new System.Windows.Forms.Label();
            this.txtkm = new System.Windows.Forms.TextBox();
            this.lblkilometer = new System.Windows.Forms.Label();
            this.lblfullamount = new System.Windows.Forms.Label();
            this.lbldiscountedamount = new System.Windows.Forms.Label();
            this.lbldiscountedamountdisplay = new System.Windows.Forms.Label();
            this.lblamountdisplay = new System.Windows.Forms.Label();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnhome = new System.Windows.Forms.Button();
            this.btncalculate = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.lblvnumber = new System.Windows.Forms.Label();
            this.lblrdate = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.lblonedaya = new System.Windows.Forms.Label();
            this.lblonedayamount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtbillcusid
            // 
            this.txtbillcusid.Location = new System.Drawing.Point(230, 109);
            this.txtbillcusid.Name = "txtbillcusid";
            this.txtbillcusid.Size = new System.Drawing.Size(249, 22);
            this.txtbillcusid.TabIndex = 27;
            // 
            // lblcusID
            // 
            this.lblcusID.AutoSize = true;
            this.lblcusID.BackColor = System.Drawing.Color.Transparent;
            this.lblcusID.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcusID.ForeColor = System.Drawing.Color.LightGray;
            this.lblcusID.Location = new System.Drawing.Point(94, 115);
            this.lblcusID.Name = "lblcusID";
            this.lblcusID.Size = new System.Drawing.Size(91, 16);
            this.lblcusID.TabIndex = 26;
            this.lblcusID.Text = "Customer ID";
            // 
            // lblvehiclenumber
            // 
            this.lblvehiclenumber.AutoSize = true;
            this.lblvehiclenumber.BackColor = System.Drawing.Color.Transparent;
            this.lblvehiclenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvehiclenumber.ForeColor = System.Drawing.Color.LightGray;
            this.lblvehiclenumber.Location = new System.Drawing.Point(596, 61);
            this.lblvehiclenumber.Name = "lblvehiclenumber";
            this.lblvehiclenumber.Size = new System.Drawing.Size(117, 16);
            this.lblvehiclenumber.TabIndex = 28;
            this.lblvehiclenumber.Text = "Vehicle Number";
            // 
            // lblindate
            // 
            this.lblindate.AutoSize = true;
            this.lblindate.BackColor = System.Drawing.Color.Transparent;
            this.lblindate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblindate.ForeColor = System.Drawing.Color.LightGray;
            this.lblindate.Location = new System.Drawing.Point(596, 114);
            this.lblindate.Name = "lblindate";
            this.lblindate.Size = new System.Drawing.Size(92, 16);
            this.lblindate.TabIndex = 30;
            this.lblindate.Text = "Rent In Date";
            // 
            // rentoutdate
            // 
            this.rentoutdate.AutoSize = true;
            this.rentoutdate.BackColor = System.Drawing.Color.Transparent;
            this.rentoutdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rentoutdate.ForeColor = System.Drawing.Color.LightGray;
            this.rentoutdate.Location = new System.Drawing.Point(94, 168);
            this.rentoutdate.Name = "rentoutdate";
            this.rentoutdate.Size = new System.Drawing.Size(103, 16);
            this.rentoutdate.TabIndex = 32;
            this.rentoutdate.Text = "Rent Out Date";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(230, 161);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(249, 22);
            this.dateTimePicker1.TabIndex = 33;
            // 
            // lblrenteddate
            // 
            this.lblrenteddate.AutoSize = true;
            this.lblrenteddate.BackColor = System.Drawing.Color.Transparent;
            this.lblrenteddate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrenteddate.ForeColor = System.Drawing.Color.LightGray;
            this.lblrenteddate.Location = new System.Drawing.Point(596, 207);
            this.lblrenteddate.Name = "lblrenteddate";
            this.lblrenteddate.Size = new System.Drawing.Size(97, 16);
            this.lblrenteddate.TabIndex = 34;
            this.lblrenteddate.Text = "Rented Days";
            // 
            // txtrec
            // 
            this.txtrec.Location = new System.Drawing.Point(230, 59);
            this.txtrec.Name = "txtrec";
            this.txtrec.Size = new System.Drawing.Size(249, 22);
            this.txtrec.TabIndex = 37;
            // 
            // lblrecieptnum
            // 
            this.lblrecieptnum.AutoSize = true;
            this.lblrecieptnum.BackColor = System.Drawing.Color.Transparent;
            this.lblrecieptnum.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrecieptnum.ForeColor = System.Drawing.Color.LightGray;
            this.lblrecieptnum.Location = new System.Drawing.Point(94, 65);
            this.lblrecieptnum.Name = "lblrecieptnum";
            this.lblrecieptnum.Size = new System.Drawing.Size(119, 16);
            this.lblrecieptnum.TabIndex = 36;
            this.lblrecieptnum.Text = "Receipt Number";
            // 
            // lbltotalamount
            // 
            this.lbltotalamount.AutoSize = true;
            this.lbltotalamount.BackColor = System.Drawing.Color.Transparent;
            this.lbltotalamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalamount.ForeColor = System.Drawing.Color.LightGray;
            this.lbltotalamount.Location = new System.Drawing.Point(596, 385);
            this.lbltotalamount.Name = "lbltotalamount";
            this.lbltotalamount.Size = new System.Drawing.Size(98, 16);
            this.lbltotalamount.TabIndex = 38;
            this.lbltotalamount.Text = "Total Amount";
            // 
            // lbltotalamountdisplay
            // 
            this.lbltotalamountdisplay.AutoSize = true;
            this.lbltotalamountdisplay.BackColor = System.Drawing.Color.Transparent;
            this.lbltotalamountdisplay.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalamountdisplay.ForeColor = System.Drawing.Color.White;
            this.lbltotalamountdisplay.Location = new System.Drawing.Point(860, 390);
            this.lbltotalamountdisplay.Name = "lbltotalamountdisplay";
            this.lbltotalamountdisplay.Size = new System.Drawing.Size(0, 21);
            this.lbltotalamountdisplay.TabIndex = 39;
            // 
            // txtkm
            // 
            this.txtkm.Location = new System.Drawing.Point(230, 214);
            this.txtkm.Name = "txtkm";
            this.txtkm.Size = new System.Drawing.Size(249, 22);
            this.txtkm.TabIndex = 41;
            // 
            // lblkilometer
            // 
            this.lblkilometer.AutoSize = true;
            this.lblkilometer.BackColor = System.Drawing.Color.Transparent;
            this.lblkilometer.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblkilometer.ForeColor = System.Drawing.Color.LightGray;
            this.lblkilometer.Location = new System.Drawing.Point(94, 220);
            this.lblkilometer.Name = "lblkilometer";
            this.lblkilometer.Size = new System.Drawing.Size(84, 16);
            this.lblkilometer.TabIndex = 40;
            this.lblkilometer.Text = "Kilo Meters";
            // 
            // lblfullamount
            // 
            this.lblfullamount.AutoSize = true;
            this.lblfullamount.BackColor = System.Drawing.Color.Transparent;
            this.lblfullamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfullamount.ForeColor = System.Drawing.Color.LightGray;
            this.lblfullamount.Location = new System.Drawing.Point(596, 255);
            this.lblfullamount.Name = "lblfullamount";
            this.lblfullamount.Size = new System.Drawing.Size(58, 16);
            this.lblfullamount.TabIndex = 42;
            this.lblfullamount.Text = "Amount";
            // 
            // lbldiscountedamount
            // 
            this.lbldiscountedamount.AutoSize = true;
            this.lbldiscountedamount.BackColor = System.Drawing.Color.Transparent;
            this.lbldiscountedamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountedamount.ForeColor = System.Drawing.Color.LightGray;
            this.lbldiscountedamount.Location = new System.Drawing.Point(596, 302);
            this.lbldiscountedamount.Name = "lbldiscountedamount";
            this.lbldiscountedamount.Size = new System.Drawing.Size(140, 16);
            this.lbldiscountedamount.TabIndex = 44;
            this.lbldiscountedamount.Text = "Discounted Amount";
            // 
            // lbldiscountedamountdisplay
            // 
            this.lbldiscountedamountdisplay.AutoSize = true;
            this.lbldiscountedamountdisplay.BackColor = System.Drawing.Color.Transparent;
            this.lbldiscountedamountdisplay.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountedamountdisplay.ForeColor = System.Drawing.Color.White;
            this.lbldiscountedamountdisplay.Location = new System.Drawing.Point(861, 307);
            this.lbldiscountedamountdisplay.Name = "lbldiscountedamountdisplay";
            this.lbldiscountedamountdisplay.Size = new System.Drawing.Size(0, 21);
            this.lbldiscountedamountdisplay.TabIndex = 45;
            // 
            // lblamountdisplay
            // 
            this.lblamountdisplay.AutoSize = true;
            this.lblamountdisplay.BackColor = System.Drawing.Color.Transparent;
            this.lblamountdisplay.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblamountdisplay.ForeColor = System.Drawing.Color.White;
            this.lblamountdisplay.Location = new System.Drawing.Point(861, 260);
            this.lblamountdisplay.Name = "lblamountdisplay";
            this.lblamountdisplay.Size = new System.Drawing.Size(0, 21);
            this.lblamountdisplay.TabIndex = 46;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.DarkGray;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.ForeColor = System.Drawing.Color.Black;
            this.btnsave.Location = new System.Drawing.Point(679, 477);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(109, 42);
            this.btnsave.TabIndex = 47;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.DarkGray;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Black;
            this.btnback.Location = new System.Drawing.Point(97, 477);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(109, 42);
            this.btnback.TabIndex = 48;
            this.btnback.Text = "<<<";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.DarkGray;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.Black;
            this.btnclear.Location = new System.Drawing.Point(496, 477);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(109, 42);
            this.btnclear.TabIndex = 49;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btnhome
            // 
            this.btnhome.BackColor = System.Drawing.Color.DarkGray;
            this.btnhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhome.ForeColor = System.Drawing.Color.Black;
            this.btnhome.Location = new System.Drawing.Point(296, 477);
            this.btnhome.Name = "btnhome";
            this.btnhome.Size = new System.Drawing.Size(109, 42);
            this.btnhome.TabIndex = 51;
            this.btnhome.Text = "Home";
            this.btnhome.UseVisualStyleBackColor = false;
            this.btnhome.Click += new System.EventHandler(this.btnhome_Click);
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.DarkGray;
            this.btncalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.ForeColor = System.Drawing.Color.Black;
            this.btncalculate.Location = new System.Drawing.Point(870, 477);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(109, 42);
            this.btncalculate.TabIndex = 52;
            this.btncalculate.Text = "Amount";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.Color.DarkGray;
            this.btnok.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnok.Location = new System.Drawing.Point(264, 296);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(109, 42);
            this.btnok.TabIndex = 53;
            this.btnok.Text = "Search";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // lblvnumber
            // 
            this.lblvnumber.AutoSize = true;
            this.lblvnumber.BackColor = System.Drawing.Color.Transparent;
            this.lblvnumber.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvnumber.ForeColor = System.Drawing.Color.White;
            this.lblvnumber.Location = new System.Drawing.Point(861, 60);
            this.lblvnumber.Name = "lblvnumber";
            this.lblvnumber.Size = new System.Drawing.Size(0, 21);
            this.lblvnumber.TabIndex = 55;
            // 
            // lblrdate
            // 
            this.lblrdate.AutoSize = true;
            this.lblrdate.BackColor = System.Drawing.Color.Transparent;
            this.lblrdate.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrdate.ForeColor = System.Drawing.Color.White;
            this.lblrdate.Location = new System.Drawing.Point(861, 218);
            this.lblrdate.Name = "lblrdate";
            this.lblrdate.Size = new System.Drawing.Size(0, 21);
            this.lblrdate.TabIndex = 56;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Location = new System.Drawing.Point(730, 114);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(249, 22);
            this.dateTimePicker2.TabIndex = 57;
            // 
            // lblonedaya
            // 
            this.lblonedaya.AutoSize = true;
            this.lblonedaya.BackColor = System.Drawing.Color.Transparent;
            this.lblonedaya.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblonedaya.ForeColor = System.Drawing.Color.LightGray;
            this.lblonedaya.Location = new System.Drawing.Point(592, 161);
            this.lblonedaya.Name = "lblonedaya";
            this.lblonedaya.Size = new System.Drawing.Size(122, 16);
            this.lblonedaya.TabIndex = 58;
            this.lblonedaya.Text = "One Day Amount";
            // 
            // lblonedayamount
            // 
            this.lblonedayamount.AutoSize = true;
            this.lblonedayamount.BackColor = System.Drawing.Color.Transparent;
            this.lblonedayamount.Font = new System.Drawing.Font("Modern No. 20", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblonedayamount.ForeColor = System.Drawing.Color.White;
            this.lblonedayamount.Location = new System.Drawing.Point(861, 166);
            this.lblonedayamount.Name = "lblonedayamount";
            this.lblonedayamount.Size = new System.Drawing.Size(0, 21);
            this.lblonedayamount.TabIndex = 59;
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Urban_Rides.Properties.Resources.normal;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1072, 553);
            this.Controls.Add(this.lblonedayamount);
            this.Controls.Add(this.lblonedaya);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.lblrdate);
            this.Controls.Add(this.lblvnumber);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.btnhome);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.lblamountdisplay);
            this.Controls.Add(this.lbldiscountedamountdisplay);
            this.Controls.Add(this.lbldiscountedamount);
            this.Controls.Add(this.lblfullamount);
            this.Controls.Add(this.txtkm);
            this.Controls.Add(this.lblkilometer);
            this.Controls.Add(this.lbltotalamountdisplay);
            this.Controls.Add(this.lbltotalamount);
            this.Controls.Add(this.txtrec);
            this.Controls.Add(this.lblrecieptnum);
            this.Controls.Add(this.lblrenteddate);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.rentoutdate);
            this.Controls.Add(this.lblindate);
            this.Controls.Add(this.lblvehiclenumber);
            this.Controls.Add(this.txtbillcusid);
            this.Controls.Add(this.lblcusID);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1090, 600);
            this.MinimumSize = new System.Drawing.Size(1090, 600);
            this.Name = "Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bill";
            this.Load += new System.EventHandler(this.Bill_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbillcusid;
        private System.Windows.Forms.Label lblcusID;
        private System.Windows.Forms.Label lblvehiclenumber;
        private System.Windows.Forms.Label lblindate;
        private System.Windows.Forms.Label rentoutdate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblrenteddate;
        private System.Windows.Forms.TextBox txtrec;
        private System.Windows.Forms.Label lblrecieptnum;
        private System.Windows.Forms.Label lbltotalamount;
        private System.Windows.Forms.Label lbltotalamountdisplay;
        private System.Windows.Forms.TextBox txtkm;
        private System.Windows.Forms.Label lblkilometer;
        private System.Windows.Forms.Label lblfullamount;
        private System.Windows.Forms.Label lbldiscountedamount;
        private System.Windows.Forms.Label lbldiscountedamountdisplay;
        private System.Windows.Forms.Label lblamountdisplay;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnhome;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Label lblvnumber;
        private System.Windows.Forms.Label lblrdate;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label lblonedaya;
        private System.Windows.Forms.Label lblonedayamount;
    }
}