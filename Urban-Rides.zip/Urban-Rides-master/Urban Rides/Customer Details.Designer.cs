﻿namespace Urban_Rides
{
    partial class Customer_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer_Details));
            this.txtcusphone = new System.Windows.Forms.TextBox();
            this.txtcusemail = new System.Windows.Forms.TextBox();
            this.txtcusaddress = new System.Windows.Forms.TextBox();
            this.txtcusname = new System.Windows.Forms.TextBox();
            this.txtcusnic = new System.Windows.Forms.TextBox();
            this.txtcusid = new System.Windows.Forms.TextBox();
            this.lblphonenum = new System.Windows.Forms.Label();
            this.lblemail = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblnic = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            this.btnsearch = new System.Windows.Forms.Button();
            this.txtenternic = new System.Windows.Forms.TextBox();
            this.lblsearch = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnback = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnview = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtcusphone
            // 
            this.txtcusphone.Location = new System.Drawing.Point(662, 441);
            this.txtcusphone.Name = "txtcusphone";
            this.txtcusphone.Size = new System.Drawing.Size(248, 22);
            this.txtcusphone.TabIndex = 30;
            // 
            // txtcusemail
            // 
            this.txtcusemail.Location = new System.Drawing.Point(662, 395);
            this.txtcusemail.Name = "txtcusemail";
            this.txtcusemail.Size = new System.Drawing.Size(248, 22);
            this.txtcusemail.TabIndex = 29;
            // 
            // txtcusaddress
            // 
            this.txtcusaddress.Location = new System.Drawing.Point(662, 352);
            this.txtcusaddress.Name = "txtcusaddress";
            this.txtcusaddress.Size = new System.Drawing.Size(248, 22);
            this.txtcusaddress.TabIndex = 28;
            // 
            // txtcusname
            // 
            this.txtcusname.Location = new System.Drawing.Point(258, 439);
            this.txtcusname.Name = "txtcusname";
            this.txtcusname.Size = new System.Drawing.Size(248, 22);
            this.txtcusname.TabIndex = 27;
            // 
            // txtcusnic
            // 
            this.txtcusnic.Location = new System.Drawing.Point(258, 393);
            this.txtcusnic.Name = "txtcusnic";
            this.txtcusnic.Size = new System.Drawing.Size(248, 22);
            this.txtcusnic.TabIndex = 26;
            // 
            // txtcusid
            // 
            this.txtcusid.Location = new System.Drawing.Point(258, 346);
            this.txtcusid.Name = "txtcusid";
            this.txtcusid.Size = new System.Drawing.Size(248, 22);
            this.txtcusid.TabIndex = 25;
            // 
            // lblphonenum
            // 
            this.lblphonenum.AutoSize = true;
            this.lblphonenum.BackColor = System.Drawing.Color.Transparent;
            this.lblphonenum.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblphonenum.ForeColor = System.Drawing.Color.LightGray;
            this.lblphonenum.Location = new System.Drawing.Point(539, 441);
            this.lblphonenum.Name = "lblphonenum";
            this.lblphonenum.Size = new System.Drawing.Size(109, 16);
            this.lblphonenum.TabIndex = 24;
            this.lblphonenum.Text = "Phone Number";
            // 
            // lblemail
            // 
            this.lblemail.AutoSize = true;
            this.lblemail.BackColor = System.Drawing.Color.Transparent;
            this.lblemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemail.ForeColor = System.Drawing.Color.LightGray;
            this.lblemail.Location = new System.Drawing.Point(539, 398);
            this.lblemail.Name = "lblemail";
            this.lblemail.Size = new System.Drawing.Size(46, 16);
            this.lblemail.TabIndex = 23;
            this.lblemail.Text = "Email";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.BackColor = System.Drawing.Color.Transparent;
            this.lbladdress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdress.ForeColor = System.Drawing.Color.LightGray;
            this.lbladdress.Location = new System.Drawing.Point(539, 355);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(65, 16);
            this.lbladdress.TabIndex = 22;
            this.lbladdress.Text = "Address";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.Color.Transparent;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.LightGray;
            this.lblname.Location = new System.Drawing.Point(135, 445);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(48, 16);
            this.lblname.TabIndex = 21;
            this.lblname.Text = "Name";
            // 
            // lblnic
            // 
            this.lblnic.AutoSize = true;
            this.lblnic.BackColor = System.Drawing.Color.Transparent;
            this.lblnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnic.ForeColor = System.Drawing.Color.LightGray;
            this.lblnic.Location = new System.Drawing.Point(135, 399);
            this.lblnic.Name = "lblnic";
            this.lblnic.Size = new System.Drawing.Size(101, 16);
            this.lblnic.TabIndex = 20;
            this.lblnic.Text = "Customer NIC";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.BackColor = System.Drawing.Color.Transparent;
            this.lblid.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.ForeColor = System.Drawing.Color.LightGray;
            this.lblid.Location = new System.Drawing.Point(135, 352);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(91, 16);
            this.lblid.TabIndex = 19;
            this.lblid.Text = "Customer ID";
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.DarkGray;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.Location = new System.Drawing.Point(874, 20);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(88, 53);
            this.btnsearch.TabIndex = 31;
            this.btnsearch.Text = "Search";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // txtenternic
            // 
            this.txtenternic.Location = new System.Drawing.Point(693, 29);
            this.txtenternic.Name = "txtenternic";
            this.txtenternic.Size = new System.Drawing.Size(174, 22);
            this.txtenternic.TabIndex = 32;
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.Location = new System.Drawing.Point(594, 29);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(72, 16);
            this.lblsearch.TabIndex = 33;
            this.lblsearch.Text = "Enter NIC";
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(104, 79);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(858, 251);
            this.dataGridView1.TabIndex = 34;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.DarkGray;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Black;
            this.btnback.Location = new System.Drawing.Point(104, 495);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(109, 42);
            this.btnback.TabIndex = 35;
            this.btnback.Text = "<<<";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.Color.DarkGray;
            this.btnclose.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclose.ForeColor = System.Drawing.Color.Black;
            this.btnclose.Location = new System.Drawing.Point(853, 495);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(109, 42);
            this.btnclose.TabIndex = 36;
            this.btnclose.Text = "Exit";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.DarkGray;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.ForeColor = System.Drawing.Color.Black;
            this.btnclear.Location = new System.Drawing.Point(258, 495);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(109, 42);
            this.btnclear.TabIndex = 37;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.Color.DarkGray;
            this.btndelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndelete.ForeColor = System.Drawing.Color.Black;
            this.btndelete.Location = new System.Drawing.Point(414, 495);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(109, 42);
            this.btndelete.TabIndex = 38;
            this.btndelete.Text = "Delete";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.DarkGray;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.Black;
            this.btnupdate.Location = new System.Drawing.Point(557, 495);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(109, 42);
            this.btnupdate.TabIndex = 39;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkGray;
            this.btnview.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.ForeColor = System.Drawing.Color.Black;
            this.btnview.Location = new System.Drawing.Point(704, 495);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(109, 42);
            this.btnview.TabIndex = 40;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // Customer_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Urban_Rides.Properties.Resources.normal1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1072, 553);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.txtenternic);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtcusphone);
            this.Controls.Add(this.txtcusemail);
            this.Controls.Add(this.txtcusaddress);
            this.Controls.Add(this.txtcusname);
            this.Controls.Add(this.txtcusnic);
            this.Controls.Add(this.txtcusid);
            this.Controls.Add(this.lblphonenum);
            this.Controls.Add(this.lblemail);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblnic);
            this.Controls.Add(this.lblid);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1090, 600);
            this.MinimumSize = new System.Drawing.Size(1090, 600);
            this.Name = "Customer_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_Details";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtcusphone;
        private System.Windows.Forms.TextBox txtcusemail;
        private System.Windows.Forms.TextBox txtcusaddress;
        private System.Windows.Forms.TextBox txtcusname;
        private System.Windows.Forms.TextBox txtcusnic;
        private System.Windows.Forms.TextBox txtcusid;
        private System.Windows.Forms.Label lblphonenum;
        private System.Windows.Forms.Label lblemail;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblnic;
        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.TextBox txtenternic;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnview;
    }
}