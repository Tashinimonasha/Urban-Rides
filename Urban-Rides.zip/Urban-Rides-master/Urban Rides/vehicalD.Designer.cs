﻿namespace Urban_Rides
{
    partial class vehicalD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(vehicalD));
            this.lblvtype = new System.Windows.Forms.Label();
            this.lblfullservice = new System.Windows.Forms.Label();
            this.lblbodywash = new System.Windows.Forms.Label();
            this.lblinterior = new System.Windows.Forms.Label();
            this.lblwax = new System.Windows.Forms.Label();
            this.lblairfreshner = new System.Windows.Forms.Label();
            this.lbloilfilter = new System.Windows.Forms.Label();
            this.lblairfilter = new System.Windows.Forms.Label();
            this.lblgear = new System.Windows.Forms.Label();
            this.lblcoolent = new System.Windows.Forms.Label();
            this.lblengine = new System.Windows.Forms.Label();
            this.txtfullservice = new System.Windows.Forms.TextBox();
            this.txtinterior = new System.Windows.Forms.TextBox();
            this.txtbodywash = new System.Windows.Forms.TextBox();
            this.txtwax = new System.Windows.Forms.TextBox();
            this.txtengine = new System.Windows.Forms.TextBox();
            this.txtairfreshner = new System.Windows.Forms.TextBox();
            this.txtoilfilter = new System.Windows.Forms.TextBox();
            this.txtairfilter = new System.Windows.Forms.TextBox();
            this.txtgear = new System.Windows.Forms.TextBox();
            this.txtcoolent = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.txthome = new System.Windows.Forms.Button();
            this.cmbvehicaltype = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnview = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblvtype
            // 
            this.lblvtype.AutoSize = true;
            this.lblvtype.BackColor = System.Drawing.Color.Transparent;
            this.lblvtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvtype.ForeColor = System.Drawing.Color.LightGray;
            this.lblvtype.Location = new System.Drawing.Point(35, 26);
            this.lblvtype.Name = "lblvtype";
            this.lblvtype.Size = new System.Drawing.Size(99, 16);
            this.lblvtype.TabIndex = 2;
            this.lblvtype.Text = "Vehical Type";
            // 
            // lblfullservice
            // 
            this.lblfullservice.AutoSize = true;
            this.lblfullservice.BackColor = System.Drawing.Color.Transparent;
            this.lblfullservice.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfullservice.ForeColor = System.Drawing.Color.LightGray;
            this.lblfullservice.Location = new System.Drawing.Point(418, 23);
            this.lblfullservice.Name = "lblfullservice";
            this.lblfullservice.Size = new System.Drawing.Size(89, 16);
            this.lblfullservice.TabIndex = 3;
            this.lblfullservice.Text = "Full Service";
            // 
            // lblbodywash
            // 
            this.lblbodywash.AutoSize = true;
            this.lblbodywash.BackColor = System.Drawing.Color.Transparent;
            this.lblbodywash.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbodywash.ForeColor = System.Drawing.Color.LightGray;
            this.lblbodywash.Location = new System.Drawing.Point(35, 76);
            this.lblbodywash.Name = "lblbodywash";
            this.lblbodywash.Size = new System.Drawing.Size(86, 16);
            this.lblbodywash.TabIndex = 4;
            this.lblbodywash.Text = "Body Wash";
            // 
            // lblinterior
            // 
            this.lblinterior.AutoSize = true;
            this.lblinterior.BackColor = System.Drawing.Color.Transparent;
            this.lblinterior.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinterior.ForeColor = System.Drawing.Color.LightGray;
            this.lblinterior.Location = new System.Drawing.Point(35, 125);
            this.lblinterior.Name = "lblinterior";
            this.lblinterior.Size = new System.Drawing.Size(120, 16);
            this.lblinterior.TabIndex = 5;
            this.lblinterior.Text = "Interior Cleaning";
            // 
            // lblwax
            // 
            this.lblwax.AutoSize = true;
            this.lblwax.BackColor = System.Drawing.Color.Transparent;
            this.lblwax.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwax.ForeColor = System.Drawing.Color.LightGray;
            this.lblwax.Location = new System.Drawing.Point(418, 122);
            this.lblwax.Name = "lblwax";
            this.lblwax.Size = new System.Drawing.Size(84, 16);
            this.lblwax.TabIndex = 6;
            this.lblwax.Text = "Wax Polish";
            // 
            // lblairfreshner
            // 
            this.lblairfreshner.AutoSize = true;
            this.lblairfreshner.BackColor = System.Drawing.Color.Transparent;
            this.lblairfreshner.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblairfreshner.ForeColor = System.Drawing.Color.LightGray;
            this.lblairfreshner.Location = new System.Drawing.Point(418, 174);
            this.lblairfreshner.Name = "lblairfreshner";
            this.lblairfreshner.Size = new System.Drawing.Size(91, 16);
            this.lblairfreshner.TabIndex = 11;
            this.lblairfreshner.Text = "Air Freshner";
            // 
            // lbloilfilter
            // 
            this.lbloilfilter.AutoSize = true;
            this.lbloilfilter.BackColor = System.Drawing.Color.Transparent;
            this.lbloilfilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloilfilter.ForeColor = System.Drawing.Color.LightGray;
            this.lbloilfilter.Location = new System.Drawing.Point(35, 177);
            this.lbloilfilter.Name = "lbloilfilter";
            this.lbloilfilter.Size = new System.Drawing.Size(65, 16);
            this.lbloilfilter.TabIndex = 10;
            this.lbloilfilter.Text = "Oil Filter";
            // 
            // lblairfilter
            // 
            this.lblairfilter.AutoSize = true;
            this.lblairfilter.BackColor = System.Drawing.Color.Transparent;
            this.lblairfilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblairfilter.ForeColor = System.Drawing.Color.LightGray;
            this.lblairfilter.Location = new System.Drawing.Point(770, 122);
            this.lblairfilter.Name = "lblairfilter";
            this.lblairfilter.Size = new System.Drawing.Size(65, 16);
            this.lblairfilter.TabIndex = 9;
            this.lblairfilter.Text = "Air Filter";
            // 
            // lblgear
            // 
            this.lblgear.AutoSize = true;
            this.lblgear.BackColor = System.Drawing.Color.Transparent;
            this.lblgear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgear.ForeColor = System.Drawing.Color.LightGray;
            this.lblgear.Location = new System.Drawing.Point(418, 73);
            this.lblgear.Name = "lblgear";
            this.lblgear.Size = new System.Drawing.Size(62, 16);
            this.lblgear.TabIndex = 8;
            this.lblgear.Text = "Gear oil";
            // 
            // lblcoolent
            // 
            this.lblcoolent.AutoSize = true;
            this.lblcoolent.BackColor = System.Drawing.Color.Transparent;
            this.lblcoolent.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcoolent.ForeColor = System.Drawing.Color.LightGray;
            this.lblcoolent.Location = new System.Drawing.Point(770, 73);
            this.lblcoolent.Name = "lblcoolent";
            this.lblcoolent.Size = new System.Drawing.Size(60, 16);
            this.lblcoolent.TabIndex = 7;
            this.lblcoolent.Text = "Coolent";
            // 
            // lblengine
            // 
            this.lblengine.AutoSize = true;
            this.lblengine.BackColor = System.Drawing.Color.Transparent;
            this.lblengine.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblengine.ForeColor = System.Drawing.Color.LightGray;
            this.lblengine.Location = new System.Drawing.Point(770, 26);
            this.lblengine.Name = "lblengine";
            this.lblengine.Size = new System.Drawing.Size(78, 16);
            this.lblengine.TabIndex = 12;
            this.lblengine.Text = "Engine Oil";
            // 
            // txtfullservice
            // 
            this.txtfullservice.Location = new System.Drawing.Point(530, 26);
            this.txtfullservice.Name = "txtfullservice";
            this.txtfullservice.Size = new System.Drawing.Size(147, 22);
            this.txtfullservice.TabIndex = 14;
            // 
            // txtinterior
            // 
            this.txtinterior.Location = new System.Drawing.Point(169, 125);
            this.txtinterior.Name = "txtinterior";
            this.txtinterior.Size = new System.Drawing.Size(147, 22);
            this.txtinterior.TabIndex = 16;
            // 
            // txtbodywash
            // 
            this.txtbodywash.Location = new System.Drawing.Point(169, 76);
            this.txtbodywash.Name = "txtbodywash";
            this.txtbodywash.Size = new System.Drawing.Size(147, 22);
            this.txtbodywash.TabIndex = 15;
            // 
            // txtwax
            // 
            this.txtwax.Location = new System.Drawing.Point(530, 122);
            this.txtwax.Name = "txtwax";
            this.txtwax.Size = new System.Drawing.Size(147, 22);
            this.txtwax.TabIndex = 17;
            // 
            // txtengine
            // 
            this.txtengine.Location = new System.Drawing.Point(879, 26);
            this.txtengine.Name = "txtengine";
            this.txtengine.Size = new System.Drawing.Size(147, 22);
            this.txtengine.TabIndex = 18;
            this.txtengine.TextChanged += new System.EventHandler(this.txtengine_TextChanged);
            // 
            // txtairfreshner
            // 
            this.txtairfreshner.Location = new System.Drawing.Point(530, 174);
            this.txtairfreshner.Name = "txtairfreshner";
            this.txtairfreshner.Size = new System.Drawing.Size(147, 22);
            this.txtairfreshner.TabIndex = 23;
            // 
            // txtoilfilter
            // 
            this.txtoilfilter.Location = new System.Drawing.Point(169, 177);
            this.txtoilfilter.Name = "txtoilfilter";
            this.txtoilfilter.Size = new System.Drawing.Size(147, 22);
            this.txtoilfilter.TabIndex = 22;
            // 
            // txtairfilter
            // 
            this.txtairfilter.Location = new System.Drawing.Point(879, 125);
            this.txtairfilter.Name = "txtairfilter";
            this.txtairfilter.Size = new System.Drawing.Size(147, 22);
            this.txtairfilter.TabIndex = 21;
            // 
            // txtgear
            // 
            this.txtgear.Location = new System.Drawing.Point(530, 73);
            this.txtgear.Name = "txtgear";
            this.txtgear.Size = new System.Drawing.Size(147, 22);
            this.txtgear.TabIndex = 20;
            // 
            // txtcoolent
            // 
            this.txtcoolent.Location = new System.Drawing.Point(879, 73);
            this.txtcoolent.Name = "txtcoolent";
            this.txtcoolent.Size = new System.Drawing.Size(147, 22);
            this.txtcoolent.TabIndex = 19;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.DarkGray;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(917, 489);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(109, 42);
            this.btnsave.TabIndex = 24;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.DarkGray;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Location = new System.Drawing.Point(687, 489);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(109, 42);
            this.btnupdate.TabIndex = 25;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.DarkGray;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(233, 489);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(109, 42);
            this.btnclear.TabIndex = 26;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // txthome
            // 
            this.txthome.BackColor = System.Drawing.Color.DarkGray;
            this.txthome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthome.Location = new System.Drawing.Point(29, 489);
            this.txthome.Name = "txthome";
            this.txthome.Size = new System.Drawing.Size(109, 42);
            this.txthome.TabIndex = 27;
            this.txthome.Text = "Home";
            this.txthome.UseVisualStyleBackColor = false;
            this.txthome.Click += new System.EventHandler(this.txthome_Click);
            // 
            // cmbvehicaltype
            // 
            this.cmbvehicaltype.FormattingEnabled = true;
            this.cmbvehicaltype.Items.AddRange(new object[] {
            "Car",
            "Van",
            "Jeep"});
            this.cmbvehicaltype.Location = new System.Drawing.Point(169, 29);
            this.cmbvehicaltype.Name = "cmbvehicaltype";
            this.cmbvehicaltype.Size = new System.Drawing.Size(147, 24);
            this.cmbvehicaltype.TabIndex = 28;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(29, 217);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(997, 253);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // btnview
            // 
            this.btnview.BackColor = System.Drawing.Color.DarkGray;
            this.btnview.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnview.Location = new System.Drawing.Point(455, 489);
            this.btnview.Name = "btnview";
            this.btnview.Size = new System.Drawing.Size(109, 42);
            this.btnview.TabIndex = 30;
            this.btnview.Text = "View";
            this.btnview.UseVisualStyleBackColor = false;
            this.btnview.Click += new System.EventHandler(this.btnview_Click);
            // 
            // vehicalD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Urban_Rides.Properties.Resources.normal7;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1072, 553);
            this.Controls.Add(this.btnview);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.cmbvehicaltype);
            this.Controls.Add(this.txthome);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txtairfreshner);
            this.Controls.Add(this.txtoilfilter);
            this.Controls.Add(this.txtairfilter);
            this.Controls.Add(this.txtgear);
            this.Controls.Add(this.txtcoolent);
            this.Controls.Add(this.txtengine);
            this.Controls.Add(this.txtwax);
            this.Controls.Add(this.txtinterior);
            this.Controls.Add(this.txtbodywash);
            this.Controls.Add(this.txtfullservice);
            this.Controls.Add(this.lblengine);
            this.Controls.Add(this.lblairfreshner);
            this.Controls.Add(this.lbloilfilter);
            this.Controls.Add(this.lblairfilter);
            this.Controls.Add(this.lblgear);
            this.Controls.Add(this.lblcoolent);
            this.Controls.Add(this.lblwax);
            this.Controls.Add(this.lblinterior);
            this.Controls.Add(this.lblbodywash);
            this.Controls.Add(this.lblfullservice);
            this.Controls.Add(this.lblvtype);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(1090, 600);
            this.MinimumSize = new System.Drawing.Size(1090, 600);
            this.Name = "vehicalD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Service Charge Details";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblvtype;
        private System.Windows.Forms.Label lblfullservice;
        private System.Windows.Forms.Label lblbodywash;
        private System.Windows.Forms.Label lblinterior;
        private System.Windows.Forms.Label lblwax;
        private System.Windows.Forms.Label lblairfreshner;
        private System.Windows.Forms.Label lbloilfilter;
        private System.Windows.Forms.Label lblairfilter;
        private System.Windows.Forms.Label lblgear;
        private System.Windows.Forms.Label lblcoolent;
        private System.Windows.Forms.Label lblengine;
        private System.Windows.Forms.TextBox txtfullservice;
        private System.Windows.Forms.TextBox txtinterior;
        private System.Windows.Forms.TextBox txtbodywash;
        private System.Windows.Forms.TextBox txtwax;
        private System.Windows.Forms.TextBox txtengine;
        private System.Windows.Forms.TextBox txtairfreshner;
        private System.Windows.Forms.TextBox txtoilfilter;
        private System.Windows.Forms.TextBox txtairfilter;
        private System.Windows.Forms.TextBox txtgear;
        private System.Windows.Forms.TextBox txtcoolent;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button txthome;
        private System.Windows.Forms.ComboBox cmbvehicaltype;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnview;
    }
}