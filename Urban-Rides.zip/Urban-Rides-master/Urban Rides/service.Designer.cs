﻿namespace Urban_Rides
{
    partial class service
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(service));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.detailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vehicalDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customerDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblcid = new System.Windows.Forms.Label();
            this.lblcnic = new System.Windows.Forms.Label();
            this.lblcname = new System.Windows.Forms.Label();
            this.lblcaddress = new System.Windows.Forms.Label();
            this.lblvnumber = new System.Windows.Forms.Label();
            this.lblvtype = new System.Windows.Forms.Label();
            this.lbltp = new System.Windows.Forms.Label();
            this.txtcid = new System.Windows.Forms.TextBox();
            this.txtcnic = new System.Windows.Forms.TextBox();
            this.txtcname = new System.Windows.Forms.TextBox();
            this.txtcaddress = new System.Windows.Forms.TextBox();
            this.txttp = new System.Windows.Forms.TextBox();
            this.txtvnumber = new System.Windows.Forms.TextBox();
            this.rdofullservice = new System.Windows.Forms.RadioButton();
            this.rdobodywash = new System.Windows.Forms.RadioButton();
            this.rdowax = new System.Windows.Forms.RadioButton();
            this.rdointerior = new System.Windows.Forms.RadioButton();
            this.rdoairfilter = new System.Windows.Forms.RadioButton();
            this.rdogear = new System.Windows.Forms.RadioButton();
            this.rdocoolent = new System.Windows.Forms.RadioButton();
            this.rdoengine = new System.Windows.Forms.RadioButton();
            this.rdoairfreshner = new System.Windows.Forms.RadioButton();
            this.rdooilfilter = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.lblquantity = new System.Windows.Forms.Label();
            this.txtcoolent = new System.Windows.Forms.TextBox();
            this.txtgear = new System.Windows.Forms.TextBox();
            this.txtengine = new System.Windows.Forms.TextBox();
            this.txtairfreshner = new System.Windows.Forms.TextBox();
            this.btnclear = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btncalculate = new System.Windows.Forms.Button();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.cmbvtype = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnhome = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DimGray;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detailsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1072, 29);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // detailsToolStripMenuItem
            // 
            this.detailsToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.detailsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vehicalDetailsToolStripMenuItem,
            this.customerDetailsToolStripMenuItem});
            this.detailsToolStripMenuItem.Font = new System.Drawing.Font("Arial", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailsToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.detailsToolStripMenuItem.Name = "detailsToolStripMenuItem";
            this.detailsToolStripMenuItem.Size = new System.Drawing.Size(84, 25);
            this.detailsToolStripMenuItem.Text = "Details";
            // 
            // vehicalDetailsToolStripMenuItem
            // 
            this.vehicalDetailsToolStripMenuItem.Name = "vehicalDetailsToolStripMenuItem";
            this.vehicalDetailsToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.vehicalDetailsToolStripMenuItem.Text = "Vehical Details";
            this.vehicalDetailsToolStripMenuItem.Click += new System.EventHandler(this.vehicalDetailsToolStripMenuItem_Click);
            // 
            // customerDetailsToolStripMenuItem
            // 
            this.customerDetailsToolStripMenuItem.Name = "customerDetailsToolStripMenuItem";
            this.customerDetailsToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.customerDetailsToolStripMenuItem.Text = "Customer Details";
            this.customerDetailsToolStripMenuItem.Click += new System.EventHandler(this.customerDetailsToolStripMenuItem_Click);
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.BackColor = System.Drawing.Color.Transparent;
            this.lblcid.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcid.ForeColor = System.Drawing.Color.LightGray;
            this.lblcid.Location = new System.Drawing.Point(15, 89);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(91, 16);
            this.lblcid.TabIndex = 1;
            this.lblcid.Text = "Customer ID";
            // 
            // lblcnic
            // 
            this.lblcnic.AutoSize = true;
            this.lblcnic.BackColor = System.Drawing.Color.Transparent;
            this.lblcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnic.ForeColor = System.Drawing.Color.LightGray;
            this.lblcnic.Location = new System.Drawing.Point(15, 146);
            this.lblcnic.Name = "lblcnic";
            this.lblcnic.Size = new System.Drawing.Size(101, 16);
            this.lblcnic.TabIndex = 2;
            this.lblcnic.Text = "Customer NIC";
            // 
            // lblcname
            // 
            this.lblcname.AutoSize = true;
            this.lblcname.BackColor = System.Drawing.Color.Transparent;
            this.lblcname.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcname.ForeColor = System.Drawing.Color.LightGray;
            this.lblcname.Location = new System.Drawing.Point(14, 198);
            this.lblcname.Name = "lblcname";
            this.lblcname.Size = new System.Drawing.Size(117, 16);
            this.lblcname.TabIndex = 3;
            this.lblcname.Text = "Customer Name";
            // 
            // lblcaddress
            // 
            this.lblcaddress.AutoSize = true;
            this.lblcaddress.BackColor = System.Drawing.Color.Transparent;
            this.lblcaddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcaddress.ForeColor = System.Drawing.Color.LightGray;
            this.lblcaddress.Location = new System.Drawing.Point(15, 255);
            this.lblcaddress.Name = "lblcaddress";
            this.lblcaddress.Size = new System.Drawing.Size(134, 16);
            this.lblcaddress.TabIndex = 4;
            this.lblcaddress.Text = "Customer Address";
            // 
            // lblvnumber
            // 
            this.lblvnumber.AutoSize = true;
            this.lblvnumber.BackColor = System.Drawing.Color.Transparent;
            this.lblvnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvnumber.ForeColor = System.Drawing.Color.LightGray;
            this.lblvnumber.Location = new System.Drawing.Point(17, 428);
            this.lblvnumber.Name = "lblvnumber";
            this.lblvnumber.Size = new System.Drawing.Size(117, 16);
            this.lblvnumber.TabIndex = 7;
            this.lblvnumber.Text = "Vehical Number";
            // 
            // lblvtype
            // 
            this.lblvtype.AutoSize = true;
            this.lblvtype.BackColor = System.Drawing.Color.Transparent;
            this.lblvtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvtype.ForeColor = System.Drawing.Color.LightGray;
            this.lblvtype.Location = new System.Drawing.Point(17, 372);
            this.lblvtype.Name = "lblvtype";
            this.lblvtype.Size = new System.Drawing.Size(99, 16);
            this.lblvtype.TabIndex = 6;
            this.lblvtype.Text = "Vehical Type";
            // 
            // lbltp
            // 
            this.lbltp.AutoSize = true;
            this.lbltp.BackColor = System.Drawing.Color.Transparent;
            this.lbltp.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltp.ForeColor = System.Drawing.Color.LightGray;
            this.lbltp.Location = new System.Drawing.Point(17, 313);
            this.lbltp.Name = "lbltp";
            this.lbltp.Size = new System.Drawing.Size(65, 16);
            this.lbltp.TabIndex = 5;
            this.lbltp.Text = "T Phone";
            // 
            // txtcid
            // 
            this.txtcid.Location = new System.Drawing.Point(158, 89);
            this.txtcid.Name = "txtcid";
            this.txtcid.Size = new System.Drawing.Size(137, 22);
            this.txtcid.TabIndex = 8;
            // 
            // txtcnic
            // 
            this.txtcnic.Location = new System.Drawing.Point(158, 146);
            this.txtcnic.Name = "txtcnic";
            this.txtcnic.Size = new System.Drawing.Size(137, 22);
            this.txtcnic.TabIndex = 9;
            // 
            // txtcname
            // 
            this.txtcname.Location = new System.Drawing.Point(158, 200);
            this.txtcname.Name = "txtcname";
            this.txtcname.Size = new System.Drawing.Size(137, 22);
            this.txtcname.TabIndex = 10;
            // 
            // txtcaddress
            // 
            this.txtcaddress.Location = new System.Drawing.Point(158, 257);
            this.txtcaddress.Name = "txtcaddress";
            this.txtcaddress.Size = new System.Drawing.Size(137, 22);
            this.txtcaddress.TabIndex = 11;
            // 
            // txttp
            // 
            this.txttp.Location = new System.Drawing.Point(158, 313);
            this.txttp.Name = "txttp";
            this.txttp.Size = new System.Drawing.Size(137, 22);
            this.txttp.TabIndex = 12;
            // 
            // txtvnumber
            // 
            this.txtvnumber.Location = new System.Drawing.Point(158, 428);
            this.txtvnumber.Name = "txtvnumber";
            this.txtvnumber.Size = new System.Drawing.Size(137, 22);
            this.txtvnumber.TabIndex = 14;
            // 
            // rdofullservice
            // 
            this.rdofullservice.AutoSize = true;
            this.rdofullservice.Location = new System.Drawing.Point(10, 25);
            this.rdofullservice.Name = "rdofullservice";
            this.rdofullservice.Size = new System.Drawing.Size(17, 16);
            this.rdofullservice.TabIndex = 15;
            this.rdofullservice.TabStop = true;
            this.rdofullservice.UseVisualStyleBackColor = true;
            this.rdofullservice.CheckedChanged += new System.EventHandler(this.rdofullservice_CheckedChanged);
            // 
            // rdobodywash
            // 
            this.rdobodywash.AutoSize = true;
            this.rdobodywash.Location = new System.Drawing.Point(11, 19);
            this.rdobodywash.Name = "rdobodywash";
            this.rdobodywash.Size = new System.Drawing.Size(17, 16);
            this.rdobodywash.TabIndex = 16;
            this.rdobodywash.TabStop = true;
            this.rdobodywash.UseVisualStyleBackColor = true;
            this.rdobodywash.CheckedChanged += new System.EventHandler(this.rdobodywash_CheckedChanged);
            // 
            // rdowax
            // 
            this.rdowax.AutoSize = true;
            this.rdowax.Location = new System.Drawing.Point(11, 21);
            this.rdowax.Name = "rdowax";
            this.rdowax.Size = new System.Drawing.Size(17, 16);
            this.rdowax.TabIndex = 18;
            this.rdowax.TabStop = true;
            this.rdowax.UseVisualStyleBackColor = true;
            this.rdowax.CheckedChanged += new System.EventHandler(this.rdowax_CheckedChanged);
            // 
            // rdointerior
            // 
            this.rdointerior.AutoSize = true;
            this.rdointerior.Location = new System.Drawing.Point(10, 20);
            this.rdointerior.Name = "rdointerior";
            this.rdointerior.Size = new System.Drawing.Size(17, 16);
            this.rdointerior.TabIndex = 17;
            this.rdointerior.TabStop = true;
            this.rdointerior.UseVisualStyleBackColor = true;
            this.rdointerior.CheckedChanged += new System.EventHandler(this.rdointerior_CheckedChanged);
            // 
            // rdoairfilter
            // 
            this.rdoairfilter.AutoSize = true;
            this.rdoairfilter.Location = new System.Drawing.Point(11, 20);
            this.rdoairfilter.Name = "rdoairfilter";
            this.rdoairfilter.Size = new System.Drawing.Size(17, 16);
            this.rdoairfilter.TabIndex = 22;
            this.rdoairfilter.TabStop = true;
            this.rdoairfilter.UseVisualStyleBackColor = true;
            this.rdoairfilter.CheckedChanged += new System.EventHandler(this.rdoairfilter_CheckedChanged);
            // 
            // rdogear
            // 
            this.rdogear.AutoSize = true;
            this.rdogear.Location = new System.Drawing.Point(15, 10);
            this.rdogear.Name = "rdogear";
            this.rdogear.Size = new System.Drawing.Size(85, 20);
            this.rdogear.TabIndex = 21;
            this.rdogear.TabStop = true;
            this.rdogear.Text = "Gear Oil";
            this.rdogear.UseVisualStyleBackColor = true;
            this.rdogear.CheckedChanged += new System.EventHandler(this.rdogear_CheckedChanged);
            // 
            // rdocoolent
            // 
            this.rdocoolent.AutoSize = true;
            this.rdocoolent.Location = new System.Drawing.Point(15, 10);
            this.rdocoolent.Name = "rdocoolent";
            this.rdocoolent.Size = new System.Drawing.Size(81, 20);
            this.rdocoolent.TabIndex = 20;
            this.rdocoolent.TabStop = true;
            this.rdocoolent.Text = "Coolent";
            this.rdocoolent.UseVisualStyleBackColor = true;
            this.rdocoolent.CheckedChanged += new System.EventHandler(this.rdocoolent_CheckedChanged);
            // 
            // rdoengine
            // 
            this.rdoengine.AutoSize = true;
            this.rdoengine.Location = new System.Drawing.Point(15, 10);
            this.rdoengine.Name = "rdoengine";
            this.rdoengine.Size = new System.Drawing.Size(99, 20);
            this.rdoengine.TabIndex = 19;
            this.rdoengine.TabStop = true;
            this.rdoengine.Text = "Engine Oil";
            this.rdoengine.UseVisualStyleBackColor = true;
            this.rdoengine.CheckedChanged += new System.EventHandler(this.rdoengine_CheckedChanged);
            // 
            // rdoairfreshner
            // 
            this.rdoairfreshner.AutoSize = true;
            this.rdoairfreshner.Location = new System.Drawing.Point(15, 9);
            this.rdoairfreshner.Name = "rdoairfreshner";
            this.rdoairfreshner.Size = new System.Drawing.Size(112, 20);
            this.rdoairfreshner.TabIndex = 24;
            this.rdoairfreshner.TabStop = true;
            this.rdoairfreshner.Text = "Air Freshner";
            this.rdoairfreshner.UseVisualStyleBackColor = true;
            this.rdoairfreshner.CheckedChanged += new System.EventHandler(this.rdoairfreshner_CheckedChanged);
            // 
            // rdooilfilter
            // 
            this.rdooilfilter.AutoSize = true;
            this.rdooilfilter.Location = new System.Drawing.Point(11, 21);
            this.rdooilfilter.Name = "rdooilfilter";
            this.rdooilfilter.Size = new System.Drawing.Size(17, 16);
            this.rdooilfilter.TabIndex = 23;
            this.rdooilfilter.TabStop = true;
            this.rdooilfilter.UseVisualStyleBackColor = true;
            this.rdooilfilter.CheckedChanged += new System.EventHandler(this.rdooilfilter_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.LightGray;
            this.label8.Location = new System.Drawing.Point(818, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(195, 29);
            this.label8.TabIndex = 25;
            this.label8.Text = "Select Services";
            // 
            // lblquantity
            // 
            this.lblquantity.AutoSize = true;
            this.lblquantity.BackColor = System.Drawing.Color.Transparent;
            this.lblquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblquantity.ForeColor = System.Drawing.Color.LightGray;
            this.lblquantity.Location = new System.Drawing.Point(974, 107);
            this.lblquantity.Name = "lblquantity";
            this.lblquantity.Size = new System.Drawing.Size(79, 20);
            this.lblquantity.TabIndex = 26;
            this.lblquantity.Text = "Quantity";
            // 
            // txtcoolent
            // 
            this.txtcoolent.Location = new System.Drawing.Point(953, 158);
            this.txtcoolent.Name = "txtcoolent";
            this.txtcoolent.Size = new System.Drawing.Size(100, 22);
            this.txtcoolent.TabIndex = 27;
            // 
            // txtgear
            // 
            this.txtgear.Location = new System.Drawing.Point(953, 206);
            this.txtgear.Name = "txtgear";
            this.txtgear.Size = new System.Drawing.Size(100, 22);
            this.txtgear.TabIndex = 28;
            // 
            // txtengine
            // 
            this.txtengine.Location = new System.Drawing.Point(953, 257);
            this.txtengine.Name = "txtengine";
            this.txtengine.Size = new System.Drawing.Size(100, 22);
            this.txtengine.TabIndex = 29;
            // 
            // txtairfreshner
            // 
            this.txtairfreshner.Location = new System.Drawing.Point(953, 304);
            this.txtairfreshner.Name = "txtairfreshner";
            this.txtairfreshner.Size = new System.Drawing.Size(100, 22);
            this.txtairfreshner.TabIndex = 30;
            // 
            // btnclear
            // 
            this.btnclear.BackColor = System.Drawing.Color.DarkGray;
            this.btnclear.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnclear.Location = new System.Drawing.Point(354, 498);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(109, 42);
            this.btnclear.TabIndex = 31;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = false;
            this.btnclear.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.Color.DarkGray;
            this.btnsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsave.Location = new System.Drawing.Point(650, 498);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(109, 42);
            this.btnsave.TabIndex = 32;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btncalculate
            // 
            this.btncalculate.BackColor = System.Drawing.Color.DarkGray;
            this.btncalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncalculate.Location = new System.Drawing.Point(944, 498);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(109, 42);
            this.btncalculate.TabIndex = 33;
            this.btncalculate.Text = "Amount";
            this.btncalculate.UseVisualStyleBackColor = false;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.BackColor = System.Drawing.Color.Transparent;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.Color.LightGray;
            this.lbltotal.Location = new System.Drawing.Point(820, 378);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(56, 22);
            this.lbltotal.TabIndex = 34;
            this.lbltotal.Text = "Total";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.BackColor = System.Drawing.Color.Transparent;
            this.lblprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprice.ForeColor = System.Drawing.Color.White;
            this.lblprice.Location = new System.Drawing.Point(903, 371);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(0, 29);
            this.lblprice.TabIndex = 35;
            // 
            // cmbvtype
            // 
            this.cmbvtype.FormattingEnabled = true;
            this.cmbvtype.Items.AddRange(new object[] {
            "--Select--",
            "Car",
            "Van",
            "Jeep"});
            this.cmbvtype.Location = new System.Drawing.Point(158, 372);
            this.cmbvtype.Name = "cmbvtype";
            this.cmbvtype.Size = new System.Drawing.Size(137, 24);
            this.cmbvtype.TabIndex = 36;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.rdofullservice);
            this.groupBox1.Location = new System.Drawing.Point(529, 71);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(131, 56);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.Location = new System.Drawing.Point(103, 24);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(17, 16);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox2.Controls.Add(this.radioButton3);
            this.groupBox2.Controls.Add(this.rdointerior);
            this.groupBox2.Location = new System.Drawing.Point(529, 186);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(131, 47);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(102, 20);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(17, 16);
            this.radioButton3.TabIndex = 50;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox3.Controls.Add(this.rdobodywash);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Location = new System.Drawing.Point(529, 133);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(131, 47);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(104, 19);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(17, 16);
            this.radioButton2.TabIndex = 49;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox4.Controls.Add(this.radioButton4);
            this.groupBox4.Controls.Add(this.rdowax);
            this.groupBox4.Location = new System.Drawing.Point(529, 239);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(131, 47);
            this.groupBox4.TabIndex = 40;
            this.groupBox4.TabStop = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(102, 21);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(17, 16);
            this.radioButton4.TabIndex = 51;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox5.Controls.Add(this.radioButton5);
            this.groupBox5.Controls.Add(this.rdoairfilter);
            this.groupBox5.Location = new System.Drawing.Point(529, 292);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(131, 47);
            this.groupBox5.TabIndex = 41;
            this.groupBox5.TabStop = false;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(102, 19);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(17, 16);
            this.radioButton5.TabIndex = 52;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.DarkGray;
            this.groupBox6.Controls.Add(this.radioButton6);
            this.groupBox6.Controls.Add(this.rdooilfilter);
            this.groupBox6.Location = new System.Drawing.Point(529, 345);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(131, 51);
            this.groupBox6.TabIndex = 42;
            this.groupBox6.TabStop = false;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(101, 20);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(17, 16);
            this.radioButton6.TabIndex = 53;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.LightGray;
            this.groupBox7.Controls.Add(this.rdocoolent);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.Black;
            this.groupBox7.Location = new System.Drawing.Point(770, 144);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(133, 36);
            this.groupBox7.TabIndex = 43;
            this.groupBox7.TabStop = false;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.LightGray;
            this.groupBox8.Controls.Add(this.rdoengine);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.Black;
            this.groupBox8.Location = new System.Drawing.Point(770, 245);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(133, 36);
            this.groupBox8.TabIndex = 43;
            this.groupBox8.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.LightGray;
            this.groupBox9.Controls.Add(this.rdogear);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.Color.Black;
            this.groupBox9.Location = new System.Drawing.Point(770, 193);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(133, 36);
            this.groupBox9.TabIndex = 43;
            this.groupBox9.TabStop = false;
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.LightGray;
            this.groupBox10.Controls.Add(this.rdoairfreshner);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.Color.Black;
            this.groupBox10.Location = new System.Drawing.Point(770, 291);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(133, 36);
            this.groupBox10.TabIndex = 43;
            this.groupBox10.TabStop = false;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.LightGray;
            this.label1.Location = new System.Drawing.Point(526, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Yes";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.LightGray;
            this.label2.Location = new System.Drawing.Point(630, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "No";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.LightGray;
            this.label3.Location = new System.Drawing.Point(401, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Full service";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.LightGray;
            this.label4.Location = new System.Drawing.Point(401, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 17);
            this.label4.TabIndex = 44;
            this.label4.Text = "Body Wash";
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.LightGray;
            this.label5.Location = new System.Drawing.Point(401, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 17);
            this.label5.TabIndex = 45;
            this.label5.Text = "Air Filter";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.LightGray;
            this.label6.Location = new System.Drawing.Point(401, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 17);
            this.label6.TabIndex = 46;
            this.label6.Text = "Wax Polish";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.LightGray;
            this.label7.Location = new System.Drawing.Point(401, 205);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 17);
            this.label7.TabIndex = 47;
            this.label7.Text = "Interior Cleaning";
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.LightGray;
            this.label9.Location = new System.Drawing.Point(401, 364);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 17);
            this.label9.TabIndex = 48;
            this.label9.Text = "Oil Filter";
            // 
            // btnhome
            // 
            this.btnhome.BackColor = System.Drawing.Color.DarkGray;
            this.btnhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhome.Location = new System.Drawing.Point(17, 498);
            this.btnhome.Name = "btnhome";
            this.btnhome.Size = new System.Drawing.Size(109, 42);
            this.btnhome.TabIndex = 49;
            this.btnhome.Text = "Home";
            this.btnhome.UseVisualStyleBackColor = false;
            this.btnhome.Click += new System.EventHandler(this.btnhome_Click);
            // 
            // service
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Urban_Rides.Properties.Resources.normal6;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1072, 553);
            this.Controls.Add(this.btnhome);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbvtype);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.txtairfreshner);
            this.Controls.Add(this.txtengine);
            this.Controls.Add(this.txtgear);
            this.Controls.Add(this.txtcoolent);
            this.Controls.Add(this.lblquantity);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtvnumber);
            this.Controls.Add(this.txttp);
            this.Controls.Add(this.txtcaddress);
            this.Controls.Add(this.txtcname);
            this.Controls.Add(this.txtcnic);
            this.Controls.Add(this.txtcid);
            this.Controls.Add(this.lblvnumber);
            this.Controls.Add(this.lblvtype);
            this.Controls.Add(this.lbltp);
            this.Controls.Add(this.lblcaddress);
            this.Controls.Add(this.lblcname);
            this.Controls.Add(this.lblcnic);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(1090, 600);
            this.MinimumSize = new System.Drawing.Size(1090, 600);
            this.Name = "service";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "service";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem detailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vehicalDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customerDetailsToolStripMenuItem;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.Label lblcnic;
        private System.Windows.Forms.Label lblcname;
        private System.Windows.Forms.Label lblcaddress;
        private System.Windows.Forms.Label lblvnumber;
        private System.Windows.Forms.Label lblvtype;
        private System.Windows.Forms.Label lbltp;
        private System.Windows.Forms.TextBox txtcid;
        private System.Windows.Forms.TextBox txtcnic;
        private System.Windows.Forms.TextBox txtcname;
        private System.Windows.Forms.TextBox txtcaddress;
        private System.Windows.Forms.TextBox txttp;
        private System.Windows.Forms.TextBox txtvnumber;
        private System.Windows.Forms.RadioButton rdofullservice;
        private System.Windows.Forms.RadioButton rdobodywash;
        private System.Windows.Forms.RadioButton rdowax;
        private System.Windows.Forms.RadioButton rdointerior;
        private System.Windows.Forms.RadioButton rdoairfilter;
        private System.Windows.Forms.RadioButton rdogear;
        private System.Windows.Forms.RadioButton rdocoolent;
        private System.Windows.Forms.RadioButton rdoengine;
        private System.Windows.Forms.RadioButton rdoairfreshner;
        private System.Windows.Forms.RadioButton rdooilfilter;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblquantity;
        private System.Windows.Forms.TextBox txtcoolent;
        private System.Windows.Forms.TextBox txtgear;
        private System.Windows.Forms.TextBox txtengine;
        private System.Windows.Forms.TextBox txtairfreshner;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btncalculate;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.ComboBox cmbvtype;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.Button btnhome;
    }
}